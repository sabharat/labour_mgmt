<?php

$customer_number;
$customer_name;

if(isset($_POST['customer_number']) && $_POST['customer_number'] !=""){
$customer_number = $_POST['customer_number'];
}else{
echo "failed"; exit;
}
if(isset($_POST['customer_name']) && $_POST['customer_name'] !=""){
$customer_name = $_POST['customer_name'];
}else{
echo "failed"; exit;
}

$conn = mysqli_connect("localhost","root","","sth_db") or die(mysql_error());
if($conn){
	$sql = "insert into customer set Customer_Number='".$customer_number."', Customer_Name='".$customer_name."'";
	
		if(mysqli_query($conn, $sql)){
		  echo "Success";
		}else{
		echo "Wrong data entered-failed";
		}
	}else{
		echo "connection failed";
	}


mysqli_close($conn);
?>