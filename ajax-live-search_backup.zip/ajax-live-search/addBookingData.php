<?php
$stock_service_date;
$customer_id;
$location;
$service_type;

if(isset($_POST['stock_service_date']) && $_POST['stock_service_date'] !="" ){
$stock_service_date = $_POST['stock_service_date'];
}else{
echo "failed"; exit;
}
if(isset($_POST['customer_id']) && $_POST['customer_id'] !=""){
$customer_id = $_POST['customer_id'];
}else{
echo "failed"; exit;
}
if(isset($_POST['location']) && $_POST['location'] !=""){
$location = $_POST['location'];
}else{
echo "failed"; exit;
}
if(isset($_POST['service_type']) && $_POST['service_type'] !=""){
$service_type = $_POST['service_type'];
}else{
$service_type = "";
}


$conn = mysqli_connect("localhost","root","","sth_db") or die(mysql_error());
if($conn){
	$sql = "insert into booking set customer_Id='".$customer_id."', Stock_Service_Date='".$stock_service_date."', Location ='".$location."', Stock_Service_Type='".$service_type."'";
	
		if(mysqli_query($conn, $sql)){
		  echo "Success";
		}else{
		echo "Wrong data entered-failed";
		}
	}else{
		echo "connection failed";
	}


mysqli_close($conn);
?>