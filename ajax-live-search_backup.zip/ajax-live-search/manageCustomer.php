<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Manage Customer Data</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	</head>
	<body>
		<div class="container">
			<br />			
			<h2 align="center">Manage Customer Data</h2><br />
			<form name="customer_add_form" id="customer_add_form" action="addCustomerData.php" method="post">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon">Phone Number</span>
					<input type="text" name="search_text_phone_number" id="search_text_phone_number" placeholder="Customer Phone Number" class="form-control" />
				</div>
				<div class="input-group">
					<span class="input-group-addon">Customer Name</span>
					<input type="text" name="search_text_customer_name" id="search_text_customer_name" placeholder="Customer Name" class="form-control" />
				</div>				
				<input type="submit" name="submit" id="submit" value="Add" >	</input>			
			</div>
			</form>
			<br />
			<div id="result"></div>
		</div>
		<div style="clear:both"></div>
		<br />
		
		<br />
		<br />
		<br />
	</body>
</html>


<script>
$(document).ready(function(){
	load_data();
	function load_data(query)
	{
		$.ajax({
			url:"fetchCustomerData.php",
			method:"post",
			data:{query:query},
			success:function(data)
			{	if(data == 'Data Not Found'){
				$('#submit').attr("disabled",false);
				$('#submit').css('color','green');			
			}else{
				$('#submit').attr("disabled",true);
				$('#submit').css('color','red');				
			}
				$('#result').html(data);
			}
		});
	}
	
	$('#search_text_phone_number').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
	
	$('#search_text_customer_name').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
	
	 $("#customer_add_form").submit(function(event) {

      /* stop form from submitting normally */
      event.preventDefault();

      /* get the action attribute from the <form action=""> element */
      var $form = $( this ),
          url = $form.attr( 'action' );
		
		if(!validatePhone()){
			alert("Please Enter Valid Value!");
			 $('#search_text_phone_number').focus();			 
			load_data();
			return false;	
		}
      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { customer_number: $('#search_text_phone_number').val(), customer_name: $('#search_text_customer_name').val() } );
		alert(posting);
      /* Alerts the results */
      posting.done(function( data ) {		  
		  $('#search_text_phone_number').val("");
		  $('#search_text_customer_name').val("");
		  load_data();
      });
    });
	
	function validatePhone(){
		var phone_number = $('#search_text_phone_number').val();
		if(phone_number.length != 10 || isNaN(phone_number)){
		return false;
		}else{
		return true;
		}
	}
});
</script>




