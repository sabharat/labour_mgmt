<?php
$connect = mysqli_connect("localhost", "root", "", "sth_db");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM customer 
	WHERE Customer_Number LIKE '%".$search."%'
	OR Customer_Name LIKE '%".$search."%' ORDER BY Add_Date Desc";
}
else
{
	$query = "
	SELECT * FROM customer ORDER BY Add_Date Desc";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
		
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>Customer Name</th>
							<th>Customer Number</th>
							<th>Booking</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{	
		$Customer_Id = $row["Customer_Id"];
		$Customer_Name = $row["Customer_Name"];
		$query2 = "SELECT count(*) as totalbooking FROM booking where Customer_Id='".$Customer_Id."'";
		$result2 = mysqli_query($connect, $query2);
		$row2 = mysqli_fetch_array($result2);
		$output .= '
			<tr>
				<td>'.$row["Customer_Name"].'</td>
				<td>'.$row["Customer_Number"].'</td>
				<td><a href="manageBooking.php?customer_id='.$Customer_Id.'&customer_name='.$Customer_Name.'">'.$row2["totalbooking"].'</a></td>				
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>