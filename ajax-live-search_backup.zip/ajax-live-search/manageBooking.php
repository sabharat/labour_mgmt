<?php
if(isset($_GET['customer_id']) && $_GET['customer_id'] !="" ){
	$customer_id = $_GET['customer_id'];
	$customer_name = $_GET['customer_name'];	
}else{
	echo "Wrong Request!"; exit;
}
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Manage Booking Data</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	</head>
	<body>
		<div class="container">
			<br />			
			<h2 align="center">Manage Booking Data</h2><br />
			<form name="booking_add_form" id="booking_add_form" action="addBookingData.php" method="post">
			<div class="form-group">
				<span class="input-group-addon"><?php echo $customer_name; ?></span>
				<div class="input-group">
					<span class="input-group-addon">Booking Date</span>
					<input type="Date" value="<?php echo date('Y-m-d'); ?>" name="search_text_stock_service_date" id="search_text_stock_service_date" class="form-control" />
				</div>
				<div class="input-group">
					<span class="input-group-addon">Location(Address)</span>
					<input type="text" name="search_text_location" id="search_text_location" placeholder="Location (Address)" class="form-control" />
				</div>
				<div class="input-group">
				<span class="input-group-addon">Service Type</span>
				<select name="service_type" id="service_type" class="form-control">
					<option>Out</option>
					<option>In</option>    
				</select>
				</div>

				<input type="submit" name="submit" id="submit" value="Add" ></input>
				<input type="hidden" name="customer_id" id="customer_id" value="<?php echo $customer_id; ?>" ></input>	
			</div>
			</form>
			<br />
			<div id="result"></div>
		</div>
		<div style="clear:both"></div>
		<br />
		
		<br />
		<br />
		<br />
	</body>
</html>


<script>
$(document).ready(function(){
	load_data();
	function load_data(query)
	{
		$.ajax({
			url:"fetchbookingData.php",
			method:"post",
			data:{query:query, 'customer_id':$("#customer_id").val()},
			success:function(data)
			{	
				$('#result').html(data);
			}
		});
	}
	
	$('#search_text_stock_service_date').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
	
	$('#search_text_location').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
	
	 $("#booking_add_form").submit(function(event) {

      /* stop form from submitting normally */
      event.preventDefault();

      /* get the action attribute from the <form action=""> element */
      var $form = $( this ),
          url = $form.attr( 'action' );
	
		var stockServiceDateString = $('#search_text_stock_service_date').val() + " 00:00:00";
				
      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { stock_service_date: stockServiceDateString, customer_id: $('#customer_id').val(), location: $('#search_text_location').val(), service_type :$('#service_type').val() } );
		
      /* Alerts the results */
      posting.done(function( data ) {
		  alert(data);		 
		  $('#search_text_location').val("");
		  load_data();
      });
    });
		
});
</script>



