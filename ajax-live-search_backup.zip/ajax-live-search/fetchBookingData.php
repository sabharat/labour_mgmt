<?php
$connect = mysqli_connect("localhost", "root", "", "sth_db");
$output = '';

$customer_id;
if(isset($_POST['customer_id']) && $_POST['customer_id'] !="" ){
	$customer_id = $_POST['customer_id'];	
}else{
 echo "No customer Id provided"; exit;
}	

if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM booking 
	WHERE Customer_Id = '".$customer_id."' AND (Stock_Service_Date LIKE '%".$search."%'
	OR Location LIKE '%".$search."%') ORDER BY Add_Date Desc";
}
else
{
	$query = "
	SELECT * FROM booking WHERE Customer_Id = '".$customer_id."' ORDER BY Add_Date Desc";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
		
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>Stock Service Date</th>
							<th>Type</th>
							<th>Location</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{	
		$Booking_Id = $row["Booking_Id"];
		
		$output .= '
			<tr>
				<td>'.$row["Stock_Service_Date"].'</td>
				<td>'.$row["Stock_Service_Type"].'</td>
				<td>'.$row["Location"].'</td>							
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>